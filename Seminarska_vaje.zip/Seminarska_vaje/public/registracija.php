<?php
require_once 'config.php';
require_once 'includes/secure_redirect.php';

// Zahtevaj HTTPS za registracijo
requireSSL();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ime = $_POST['ime'] ?? '';
    $priimek = $_POST['priimek'] ?? '';
    $email = $_POST['email'] ?? '';
    $geslo = $_POST['geslo'] ?? '';
    $geslo_potrditev = $_POST['geslo_potrditev'] ?? '';
    $postna_stevilka = $_POST['postna_stevilka'] ?? '';

    // Preverjanje, če so vsa polja izpolnjena
    if (empty($ime) || empty($priimek) || empty($email) || empty($geslo) || 
        empty($geslo_potrditev) || empty($postna_stevilka)) {
        $error = 'Prosim izpolnite vsa polja.';
    }
    // Preverjanje, če se gesli ujemata
    elseif ($geslo !== $geslo_potrditev) {
        $error = 'Gesli se ne ujemata.';
    }
    // Preverjanje dolžine gesla
    elseif (strlen($geslo) < 6) {
        $error = 'Geslo mora biti dolgo vsaj 6 znakov.';
    }
    // Preverjanje veljavnosti email naslova
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Prosim vnesite veljaven email naslov.';
    }
    // Preverjanje poštne številke (točno 4 številke)
    elseif (!preg_match('/^[0-9]{4}$/', $postna_stevilka)) {
        $error = 'Poštna številka mora vsebovati točno 4 številke.';
    }
    else {
        // Preverjanje, če email že obstaja
        $stmt = $pdo->prepare("SELECT id FROM stranka WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Ta email naslov je že registriran.';
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO stranka (ime, priimek, email, geslo, postna_stevilka) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([
                    $ime,
                    $priimek,
                    $email,
                    password_hash($geslo, PASSWORD_DEFAULT),
                    $postna_stevilka
                ]);
                
                $success = 'Registracija uspešna! Zdaj se lahko prijavite.';
            } catch (PDOException $e) {
                $error = 'Prišlo je do napake pri registraciji. Prosim poskusite ponovno.';
            }
        }
    }
}

// Ostala koda ostane enaka...
?>
