<?php
require_once __DIR__ . '/../config/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Pridobi vse aktivne izdelke
$stmt = $pdo->prepare("SELECT id, naziv, opis, cena FROM artikel WHERE aktiven = TRUE ORDER BY naziv");
$stmt->execute();
$izdelki = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="sl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spletna Prodajalna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="index.php">Spletna Prodajalna</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['stranka_id'])): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="../stranka/narocila.php">Moja Naročila</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../stranka/profil.php">Moj Profil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="kosarica.php">Košarica</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="odjava.php">Odjava</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="login.php">Prijava</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="registracija.php">Registracija</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h1 class="mb-4">Izdelki</h1>
        
        <div class="row">
            <?php foreach ($izdelki as $izdelek): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($izdelek['naziv']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($izdelek['opis']) ?></p>
                            <p class="card-text"><strong>Cena: <?= number_format($izdelek['cena'], 2) ?> €</strong></p>
                            <?php if (isset($_SESSION['stranka_id'])): ?>
                                <button class="btn btn-primary dodaj-v-kosaro" data-izdelek-id="<?= $izdelek['id'] ?>">
                                    Dodaj v košarico
                                </button>
                            <?php else: ?>
                                <a href="login.php" class="btn btn-primary">Prijava za nakup</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/kosarica.js"></script>
</body>
</html>
